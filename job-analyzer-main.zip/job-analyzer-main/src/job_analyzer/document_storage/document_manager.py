"""Document storage manager for handling uploaded files."""

import uuid
import logging
from pathlib import Path
from typing import Optional, Dict, Any
import xxhash

from fastapi import UploadFile
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from utils.vars import get_app_path
from utils.constants import UPLOADED_FILE_FOLDER
from utils.document_extractor import extract_text_in_memory
from utils.document_summarizer import summarize_document
from job_analyzer.document_storage.models import UploadedDocument
from job_analyzer.database.models import Document as DBDocument
from job_analyzer.database.core import Database

logger = logging.getLogger(__name__)


async def save_uploaded_document(
    file: UploadFile,
    doc_type: str = "other",
    session_id: Optional[str] = None,
) -> UploadedDocument:
    """
    Save an uploaded document and extract its text.
    """
    try:
        logger.debug(
            f"Starting document upload: {file.filename}, type: {doc_type}, session: {session_id}"
        )
        # Read file content
        contents = await file.read()
        file_hash = xxhash.xxh64(contents).hexdigest()

        # Check if already exists in DB
        db = Database.get_instance()
        async with db.get_session() as session:
            existing_doc = await _find_document_by_hash(session, file_hash)
            if existing_doc:
                logger.info(f"Document already exists with hash {file_hash}")
                return _map_db_to_domain(existing_doc)

        if not file or file.filename:
            raise ValueError("No file uploaded or filename is empty")

        ext = Path(file.filename).suffix.lower().lstrip(".")  # type: ignore

        text = await extract_text_in_memory(contents, ext)

        summary = await summarize_document(text, doc_type=doc_type)

        # Create document record
        doc_id = str(uuid.uuid4())

        db_doc = DBDocument(
            id=doc_id,
            file_hash=file_hash,
            original_filename=file.filename,
            file_type=doc_type,
            extracted_text=text,
            summary=summary,
            doc_metadata={
                "file_extension": ext,
                "session_id": session_id,
            },
        )

        async with db.get_session() as session:
            session.add(db_doc)
            await session.commit()

        logger.info(f"Stored document {doc_id} ({doc_type}) in DB")
        logger.info(f"DEBUG: db_doc type before map: {type(db_doc)}")

        domain_doc = _map_db_to_domain(db_doc)
        return domain_doc

    except Exception as e:
        logger.error(f"Error saving document EXCEPTION TYPE: {type(e)}")
        logger.error(f"Error saving document: {str(e)}", exc_info=True)
        raise


async def save_text_document(
    text: str,
    doc_type: str = "other",
    filename: str = "pasted_text.txt",
    session_id: Optional[str] = None,
    summarize: bool = True,
) -> UploadedDocument:
    """
    Save pasted/typed text as a document.
    """
    try:
        logger.debug(
            f"Starting text document save. Type: {doc_type}, filename: {filename}, session: {session_id}"
        )
        # Create hash of text
        text_hash = xxhash.xxh64(text.encode()).hexdigest()

        # Check if already exists
        db = Database.get_instance()
        async with db.get_session() as session:
            existing_doc = await _find_document_by_hash(session, text_hash)
            if existing_doc:
                logger.info(f"Text document already exists with hash {text_hash}")
                return _map_db_to_domain(existing_doc)

        # Summarize if needed
        summary = None
        if summarize:
            from utils.document_summarizer import summarize_document

            summary = await summarize_document(text, doc_type=doc_type)

        # Create document record
        doc_id = str(uuid.uuid4())

        db_doc = DBDocument(
            id=doc_id,
            file_hash=text_hash,
            original_filename=filename,
            file_type=doc_type,
            extracted_text=text,
            summary=summary,
            doc_metadata={"source": "paste", "session_id": session_id},
        )

        async with db.get_session() as session:
            session.add(db_doc)
            await session.commit()

        logger.info(f"Stored text document {doc_id} ({doc_type}) in DB")

        domain_doc = _map_db_to_domain(db_doc)
        return domain_doc

    except Exception as e:
        logger.error(f"Error saving text document: {str(e)}", exc_info=True)
        raise


async def get_document(doc_id: str) -> Optional[UploadedDocument]:
    """
    Retrieve a document by ID.
    """

    db = Database.get_instance()
    async with db.get_session() as session:
        stmt = select(DBDocument).where(DBDocument.id == doc_id)
        result = await session.execute(stmt)
        db_doc = result.scalar_one_or_none()

        if db_doc:
            domain_doc = _map_db_to_domain(db_doc)
            return domain_doc

    logger.debug(f"Document {doc_id} not found in DB")
    return None


async def _find_document_by_hash(
    session: AsyncSession, file_hash: str
) -> Optional[DBDocument]:
    """Find a document by its file hash."""
    stmt = select(DBDocument).where(DBDocument.file_hash == file_hash)
    result = await session.execute(stmt)
    return result.scalar_one_or_none()


def _map_db_to_domain(db_doc: Any) -> UploadedDocument:
    """Maps DB model to Domain model

    Args:
        db_doc (DBDocument): The database document model.
    Returns:
        UploadedDocument: The domain document model.
    """

    text_to_use = db_doc.summary if db_doc.summary else db_doc.extracted_text  # type: ignore

    return UploadedDocument(
        id=db_doc.id,
        file_hash=db_doc.file_hash,
        original_filename=db_doc.original_filename,
        file_type=db_doc.file_type,
        file_format=(
            db_doc.doc_metadata.get("file_extension", "txt")
            if db_doc.doc_metadata
            else "txt"
        ),
        extracted_text=text_to_use,
        session_id=(
            db_doc.doc_metadata.get("session_id") if db_doc.doc_metadata else None
        ),
        metadata=db_doc.doc_metadata or {},
    )
