from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from sqlalchemy.exc import NoResultFound

from job_analyzer.database.models import Configuration
from utils.app_config import AppConfig
import logging

logger = logging.getLogger(__name__)

CONFIG_KEY = "current_config"


async def get_active_config(session: AsyncSession) -> AppConfig:
    """
    Retrieves the active configuration from the database.
    If no configuration exists, it creates one from the default AppConfig.
    """
    logger.debug("Fetching active configuration from database")
    stmt = select(Configuration).where(Configuration.key == CONFIG_KEY)
    result = await session.execute(stmt)
    config_record = result.scalar_one_or_none()

    if config_record:
        logger.debug("Configuration found in database")
        # Validate and return existing config
        try:
            return AppConfig(**config_record.data)
        except Exception as e:
            logger.error(f"Failed to parse config from DB: {e}. Returning default.")
            # Fallback to default if DB data is corrupted, but don't overwrite yet
            return AppConfig.default()
    else:
        logger.info("No configuration found in database. Creating default.")
        default_config = AppConfig.default()
        new_record = Configuration(
            key=CONFIG_KEY, data=default_config.model_dump(mode="json")
        )
        session.add(new_record)
        await session.commit()
        return default_config


async def update_config(session: AsyncSession, new_config: AppConfig) -> AppConfig:
    """Updates the active configuration in the database."""
    logger.info("Updating configuration in database")

    stmt = select(Configuration).where(Configuration.key == CONFIG_KEY)
    result = await session.execute(stmt)
    config_record = result.scalar_one_or_none()

    if config_record:
        config_record.data = new_config.model_dump(mode="json")
        await session.commit()
        logger.info("Configuration updated successfully")
        return new_config
    else:
        # Should not happen if get_active_config was called on startup, but handle safely
        logger.warning("Configuration record missing during update. Creating new.")
        new_record = Configuration(
            key=CONFIG_KEY, data=new_config.model_dump(mode="json")
        )
        session.add(new_record)
        await session.commit()
        return new_config
