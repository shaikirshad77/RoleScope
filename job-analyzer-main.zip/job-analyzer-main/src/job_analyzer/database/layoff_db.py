from typing import Optional
from contextvars import ContextVar
from sqlalchemy.sql import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import and_
from datetime import datetime, timedelta

from job_analyzer.database.models import LayOff
from job_analyzer.database.core import Database


layoff_db_context: ContextVar[AsyncSession] = ContextVar("layoff_context")


async def get_recent_layoff(
    company_name: Optional[str] = None,
    days: Optional[int] = None,
    hq_location: Optional[str] = None,
    industry: Optional[str] = None,
    date: Optional[str] = None,
    stage: Optional[str] = None,
    country: Optional[str] = None,
    limit: int = 5,
    offset: int = 0,
    session: Optional[AsyncSession] = None,
) -> list[LayOff]:
    """Retrieve recent layoff records based on various filters."""

    # Session fallback logic
    close_session = False

    if session is None:
        try:
            session = layoff_db_context.get()
        except LookupError:
            # If no session is in context, get one from the singleton
            session = Database.get_instance().get_session()
            close_session = True

    filters = []

    if company_name:
        filters.append(LayOff.company.ilike(company_name))
    if hq_location:
        filters.append(LayOff.hq_location.ilike(hq_location))
    if industry:
        filters.append(LayOff.industry.ilike(industry))
    if stage:
        filters.append(LayOff.stage.ilike(stage))
    if country:
        filters.append(LayOff.country.ilike(country))
    if date:
        filters.append(LayOff.date == date)
    elif days is not None:
        since_date = datetime.now().date() - timedelta(days=days)
        filters.append(LayOff.date >= since_date)

    stmt = select(LayOff)
    if filters:
        stmt = stmt.where(and_(*filters))
    stmt = stmt.limit(limit).offset(offset)

    try:
        result = await session.execute(stmt)
        return list(result.scalars().all())

    finally:
        if close_session:
            await session.close()


async def get_field_unique_values(
    field_name: str, session: Optional[AsyncSession] = None
) -> list[str]:
    """Get unique values for a specific field in the LayOff table."""
    close_session = False
    if session is None:
        try:
            session = layoff_db_context.get()
        except LookupError:
            session = Database.get_instance().get_session()
            close_session = True

    try:
        stmt = select(getattr(LayOff, field_name)).distinct()
        result = await session.execute(stmt)
        return [row[0] for row in result.fetchall() if row[0] is not None]
    finally:
        if close_session:
            await session.close()


async def add_layoff(layoff: LayOff, session: Optional[AsyncSession] = None) -> None:
    """Add a layoff record to the database."""
    close_session = False
    if session is None:
        try:
            session = layoff_db_context.get()
        except LookupError:
            session = Database.get_instance().get_session()
            close_session = True

    try:
        async with session.begin():  # This manages the transaction
            session.add(layoff)
    finally:
        if close_session:
            await session.close()


async def add_layoff_bulk(
    layoffs: list[LayOff], session: Optional[AsyncSession] = None
) -> None:
    """Add list of multiple record to the database."""
    close_session = False
    if session is None:
        try:
            session = layoff_db_context.get()
        except LookupError:
            session = Database.get_instance().get_session()
            close_session = True

    try:
        async with session.begin():
            session.add_all(layoffs)
    finally:
        if close_session:
            await session.close()


async def add_partial_layoff(
    layoffs: list[LayOff], session: Optional[AsyncSession] = None
) -> None:
    """Only Add Layoff records that do not already exist in the database.
    Terminates early if a duplicate is found as all subsequent records would be duplicates.
    """
    close_session = False
    if session is None:
        try:
            session = layoff_db_context.get()
        except LookupError:
            session = Database.get_instance().get_session()
            close_session = True

    try:
        incoming_signatures = {l.row_signature for l in layoffs}

        stmt = select(LayOff.row_signature).where(
            LayOff.row_signature.in_(incoming_signatures)
        )
        result = await session.execute(stmt)
        existing_signatures = {row[0] for row in result.fetchall()}

        new_layoffs = [l for l in layoffs if l.row_signature not in existing_signatures]

        if new_layoffs:
            async with session.begin():
                session.add_all(new_layoffs)
    finally:
        if close_session:
            await session.close()


async def update_layoff(layoff: LayOff, session: Optional[AsyncSession] = None) -> None:
    """Update an existing layoff record in the database."""
    close_session = False
    if session is None:
        try:
            session = layoff_db_context.get()
        except LookupError:
            session = Database.get_instance().get_session()
            close_session = True

    try:
        async with session.begin():
            await session.merge(layoff)
    finally:
        if close_session:
            await session.close()


async def delete_layoff(layoff_id: int, session: Optional[AsyncSession] = None) -> None:
    """Delete a layoff record from the database by its ID."""
    close_session = False
    if session is None:
        try:
            session = layoff_db_context.get()
        except LookupError:
            session = Database.get_instance().get_session()
            close_session = True

    try:
        async with session.begin():
            stmt = select(LayOff).where(LayOff.id == layoff_id)
            result = await session.execute(stmt)
            layoff_record = result.scalar_one_or_none()

            if layoff_record:
                await session.delete(layoff_record)
    finally:
        if close_session:
            await session.close()
