from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from typing import Optional


class Database:
    _instance: Optional["Database"] = None

    def __init__(self):
        self._engine: Optional[AsyncEngine] = None
        self._sessionmaker: Optional[async_sessionmaker[AsyncSession]] = None

    @classmethod
    def get_instance(cls) -> "Database":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def init(self, db_url: str) -> None:
        """Initialize the database connection."""
        if self._engine is not None:
            # Already initialized
            return

        self._engine = create_async_engine(db_url)
        self._sessionmaker = async_sessionmaker(
            self._engine, expire_on_commit=False, class_=AsyncSession
        )

    async def close(self) -> None:
        """Close the database connection."""
        if self._engine:
            await self._engine.dispose()
            self._engine = None
            self._sessionmaker = None

    def get_session(self) -> AsyncSession:
        """Get a new database session."""
        if self._sessionmaker is None:
            raise RuntimeError("Database is not initialized. Call init() first.")
        return self._sessionmaker()

    @property
    def engine(self) -> AsyncEngine:
        """Get the database engine."""
        if self._engine is None:
            raise RuntimeError("Database is not initialized. Call init() first.")
        return self._engine
