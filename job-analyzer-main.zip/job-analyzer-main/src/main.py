import os
import uvicorn
from dotenv import load_dotenv
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
import logging

from utils.vars import get_app_path, get_job_analyzer_db
from utils.constants import UPLOADED_FILE_FOLDER
from routes.app_route import router
from job_analyzer.database.models import Base
from job_analyzer.database.layoff_db import layoff_db_context
from job_analyzer.database.core import Database
from job_analyzer.database.config_db import get_active_config

load_dotenv()

from utils.logging_utils import setup_logging

# Defer logging setup until config is loaded
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):

    logger.info("Application startup: Initializing Database...")

    # Create uploads directory if it doesn't exist
    uploads_path = get_app_path().joinpath(UPLOADED_FILE_FOLDER)
    if not uploads_path.exists():
        os.makedirs(uploads_path)
        logger.info(f"Created uploads directory at: {uploads_path}")

    # Initialize Database
    db = Database.get_instance()
    db.init(get_job_analyzer_db())

    async with db.engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    logger.info("Database initialized. Loading configuration...")

    # Load Configuration from DB
    async with db.get_session() as session:
        app_config = await get_active_config(session)
        app.state.config = app_config

    # Re-setup logging with config
    setup_logging(app_config.app_setting.logging)
    logger.info("Configuration loaded and logging configured.")

    yield

    logger.info("Application shutdown: Disposing database engine...")

    await db.close()

    logger.info("Engine Disposed")


app = FastAPI(lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


@app.middleware("http")
async def db_session_middleware(request: Request, call_next):
    """
    Creates a new DB session for each request, sets it in the context
    and ensures it's closed after the request is finished
    """
    session = Database.get_instance().get_session()

    token = layoff_db_context.set(session)

    try:
        response = await call_next(request)

    finally:
        await session.close()
        layoff_db_context.reset(token)

    return response


app.include_router(router, prefix="/api/v1")

if __name__ == "__main__":

    logger.info("Starting Uvicorn server for FastAPI application...")

    uvicorn.run(app, host="0.0.0.0", port=8100)
