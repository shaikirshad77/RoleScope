from typing import Callable, Coroutine, Any, Dict, List, Optional, Tuple, Union
from fastapi import WebSocket

from langchain_core.tools import BaseTool
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import (
    BaseMessage,
    AIMessageChunk,
    ToolMessage,
    AIMessage,
)

from llm.base.inference import BaseInference
from llm.base.callbacks import CallBackHandler
from utils.vars import get_gemini_api_key
from utils.app_config import AppConfig
import logging

logger = logging.getLogger(__name__)


class GeminiInference(BaseInference):
    """Gemini Inference Engine."""

    def __init__(
        self,
        app_config: AppConfig = AppConfig.load_default(),
    ):
        self.app_config = app_config
        self.llm = ChatGoogleGenerativeAI(
            model=self.app_config.inference.inference_config.gemini.model,
            google_api_key=get_gemini_api_key(),
            temperature=self.app_config.inference.inference_config.gemini.temperature,
            max_output_tokens=self.app_config.inference.inference_config.gemini.max_tokens,
        )
        logger.info(
            f"GeminiInference initialized with model: {self.app_config.inference.inference_config.gemini.model}"
        )
        self.function_call_handler: Optional[
            Callable[[str, str, str], Coroutine[Any, Any, ToolMessage]]
        ] = None
        self.llm_with_tools: Optional[Any] = None

    def tools(self, tools: list[BaseTool]) -> "GeminiInference":
        """Set tools for the language model."""
        if not isinstance(self.llm, ChatGoogleGenerativeAI):
            raise ValueError(
                "LLM must be an instance of GoogleGenerateAI to bind tools."
            )

        self.llm_with_tools = self.llm.bind_tools(tools)
        return self

    def tools_handler(
        self,
        tool_handler: Callable[[str, str, str], Coroutine[Any, Any, ToolMessage]],
    ) -> "GeminiInference":
        """Set Function Call handler for tools"""
        self.function_call_handler = tool_handler
        return self

    async def stream(
        self,
        websocket: WebSocket,
        messages: list[BaseMessage],
        max_depth: int = 5,
        depth: int = 0,
        response_str: str = "",
    ) -> str:
        """Recursively process tool calls and stream responses."""

        if depth >= max_depth:
            logger.warning(f"Max depth {max_depth} reached in stream recursion")
            return response_str

        logger.debug(
            f"Stream called with depth {depth}, message count: {len(messages)}"
        )

        tool_calls_args: Dict[Tuple[str, str], str] = {}
        last_tool_info: Dict[str, str] = {"name": "", "id": ""}

        model_to_use = self.llm_with_tools if self.llm_with_tools else self.llm

        async for chunk in model_to_use.astream(
            messages, {"callbacks": [CallBackHandler(websocket)]}
        ):
            await self._process_stream_chunk(
                chunk, websocket, response_str, tool_calls_args, last_tool_info
            )
            if isinstance(chunk.content, str) and chunk.content:
                response_str += chunk.content
            elif isinstance(chunk.content, list) and chunk.content:
                texts = [c["text"] for c in chunk.content if "text" in c]
                response_str += "\n".join(texts)

        if not tool_calls_args:
            logger.debug("No tool calls found in stream chunk")
            return response_str

        logger.info(f"Processing {len(tool_calls_args)} tool calls")
        tool_messages = await self._execute_tool_calls(tool_calls_args)

        next_messages = [AIMessage(content=response_str)] + tool_messages
        return await self.stream(
            websocket, messages + next_messages, max_depth, depth + 1, response_str
        )

    async def _process_stream_chunk(
        self,
        chunk: Any,
        websocket: WebSocket,
        response_str: str,
        tool_calls_args: Dict[Tuple[str, str], str],
        last_tool_info: Dict[str, str],
    ):
        """Process a single chunk from the stream."""

        # Handle Content Streaming
        if isinstance(chunk.content, str) and chunk.content:
            await websocket.send_text(chunk.content)

        if isinstance(chunk.content, list) and chunk.content:
            current_response = [
                content["text"] for content in chunk.content if "text" in content
            ]
            if current_response:
                await websocket.send_text("\n".join(current_response))

        # Handle Tool Calls
        if not isinstance(chunk, AIMessageChunk):
            return

        if chunk.tool_calls:
            for tool_call in chunk.tool_calls:
                if tool_call.get("name") and tool_call.get("id"):
                    tool_calls_args[(tool_call["name"], tool_call["id"])] = ""
                    last_tool_info["name"] = tool_call["name"]
                    last_tool_info["id"] = tool_call["id"]

        if "tool_calls" in chunk.additional_kwargs:
            for tool_call in chunk.additional_kwargs["tool_calls"]:
                name = last_tool_info["name"]
                id_ = last_tool_info["id"]
                if name and id_:
                    arguments = tool_call.get("function", {}).get("arguments", "")
                    tool_calls_args[(name, id_)] += arguments

    async def _execute_tool_calls(
        self, tool_calls_args: Dict[Tuple[str, str], str]
    ) -> List[ToolMessage]:
        """Execute collected tool calls."""
        if not self.function_call_handler:
            logger.error("Function call handler is not set, cannot execute tools.")
            return []

        tool_messages = []
        for (tool_name, tool_id), args in tool_calls_args.items():
            if tool_name and tool_id:
                try:
                    message = await self.function_call_handler(tool_id, tool_name, args)
                    tool_messages.append(message)
                except Exception as e:
                    logger.error(f"Error executing tool {tool_name}: {e}")
        return tool_messages

    async def chat(self, messages: list[BaseMessage]) -> str:
        """Generate a response from the language model based on the provided messages."""
        if not self.llm:
            return ""

        logger.debug(f"Invoking chat with {len(messages)} messages")
        response = await self.llm.ainvoke(messages)

        if isinstance(response.content, str):
            return response.content
        return str(response.content)
