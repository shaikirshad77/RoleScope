import unittest
from unittest.mock import MagicMock, patch, AsyncMock
from sqlalchemy.ext.asyncio import AsyncSession, AsyncEngine
from job_analyzer.database.core import Database


class TestDatabaseSingleton(unittest.IsolatedAsyncioTestCase):
    """Test the Database Singleton class."""

    async def asyncSetUp(self):
        # Reset the singleton instance before each test
        Database._instance = None

    async def asyncTearDown(self):
        db = Database.get_instance()
        # Mock engine dispose if engine exists and is a mock
        if db._instance and db._engine and isinstance(db._engine, MagicMock):
            # Ensure dispose is an AsyncMock if it's not
            if not isinstance(db._engine.dispose, (AsyncMock, MagicMock)):
                pass
            elif not hasattr(db._engine.dispose, "side_effect") and not isinstance(
                db._engine.dispose, AsyncMock
            ):
                # If it's a plain MagicMock, replace it with AsyncMock to avoid await errors
                db._engine.dispose = AsyncMock()

        try:
            await db.close()
        except TypeError:
            # Fallback if await fails on a mock
            pass
        Database._instance = None

    def test_singleton_instance(self):
        """Test that get_instance returns the same instance."""
        db1 = Database.get_instance()
        db2 = Database.get_instance()
        self.assertIs(db1, db2)

    @patch("job_analyzer.database.core.create_async_engine")
    @patch("job_analyzer.database.core.async_sessionmaker")
    def test_init(self, mock_sessionmaker, mock_create_engine):
        """Test initialization of the database."""
        db = Database.get_instance()
        db_url = "sqlite+aiosqlite:///:memory:"

        # Setup mock engine to be awaitable on dispose
        mock_engine = MagicMock(spec=AsyncEngine)
        mock_engine.dispose = AsyncMock()
        mock_create_engine.return_value = mock_engine

        db.init(db_url)

        mock_create_engine.assert_called_once_with(db_url)
        mock_sessionmaker.assert_called_once()
        self.assertIsNotNone(db._engine)
        self.assertIsNotNone(db._sessionmaker)

    def test_get_session_without_init(self):
        """Test that get_session raises RuntimeError if not initialized."""
        db = Database.get_instance()
        with self.assertRaises(RuntimeError):
            db.get_session()

    @patch("job_analyzer.database.core.create_async_engine")
    @patch("job_analyzer.database.core.async_sessionmaker")
    def test_get_session(self, mock_sessionmaker, mock_create_engine):
        """Test getting a session."""
        db = Database.get_instance()

        # Setup mock engine
        mock_engine = MagicMock(spec=AsyncEngine)
        mock_engine.dispose = AsyncMock()
        mock_create_engine.return_value = mock_engine

        db.init("sqlite+aiosqlite:///:memory:")

        mock_session = MagicMock(spec=AsyncSession)
        db._sessionmaker.return_value = mock_session

        session = db.get_session()
        self.assertEqual(session, mock_session)

    @patch("job_analyzer.database.core.create_async_engine")
    @patch("job_analyzer.database.core.async_sessionmaker")
    async def test_close(self, mock_sessionmaker, mock_create_engine):
        """Test closing the database."""
        db = Database.get_instance()

        mock_engine = MagicMock(spec=AsyncEngine)
        mock_engine.dispose = AsyncMock()
        mock_create_engine.return_value = mock_engine

        db.init("sqlite+aiosqlite:///:memory:")

        await db.close()

        mock_engine.dispose.assert_called_once()
        self.assertIsNone(db._engine)
        self.assertIsNone(db._sessionmaker)


if __name__ == "__main__":
    unittest.main()
