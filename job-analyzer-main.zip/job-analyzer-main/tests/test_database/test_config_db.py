import unittest
from unittest.mock import MagicMock, AsyncMock, patch
from job_analyzer.database.config_db import get_active_config, update_config, CONFIG_KEY
from job_analyzer.database.models import Configuration
from utils.app_config import AppConfig


class TestConfigDB(unittest.IsolatedAsyncioTestCase):
    async def test_get_active_config_exists(self):
        """Test retrieving existing configuration."""
        mock_session = AsyncMock()
        mock_result = MagicMock()

        # Mock existing record
        mock_record = MagicMock()
        mock_record.data = AppConfig.default().model_dump(mode="json")
        mock_result.scalar_one_or_none.return_value = mock_record
        mock_session.execute.return_value = mock_result

        config = await get_active_config(mock_session)

        self.assertIsInstance(config, AppConfig)
        mock_session.execute.assert_called()

    async def test_get_active_config_defaults(self):
        """Test retrieving configuration when none exists (should create default)."""
        mock_session = AsyncMock()
        mock_result = MagicMock()

        # Mock no record
        mock_result.scalar_one_or_none.return_value = None
        mock_session.execute.return_value = mock_result

        config = await get_active_config(mock_session)

        self.assertIsInstance(config, AppConfig)
        mock_session.add.assert_called()
        mock_session.commit.assert_called()

    async def test_update_config(self):
        """Test updating configuration."""
        mock_session = AsyncMock()
        mock_result = MagicMock()

        # Mock existing record
        mock_record = MagicMock()
        mock_record.data = {}
        mock_result.scalar_one_or_none.return_value = mock_record
        mock_session.execute.return_value = mock_result

        new_config = AppConfig.default()
        updated = await update_config(mock_session, new_config)

        self.assertEqual(updated, new_config)
        self.assertEqual(mock_record.data, new_config.model_dump(mode="json"))
        mock_session.commit.assert_called()


if __name__ == "__main__":
    unittest.main()
