import unittest
import uuid
from unittest.mock import MagicMock, AsyncMock, patch
from fastapi import UploadFile
from job_analyzer.document_storage.document_manager import (
    save_uploaded_document,
    get_document,
    save_text_document,
    _document_cache,
)
from job_analyzer.document_storage.models import UploadedDocument
from job_analyzer.database.models import Document as DBDocument
from job_analyzer.database.core import Database


class TestDBDocumentManager(unittest.IsolatedAsyncioTestCase):

    async def asyncSetUp(self):
        # Clear cache
        _document_cache.clear()

    async def test_save_uploaded_document_new(self):
        """Test saving a new uploaded document."""
        mock_file = MagicMock(spec=UploadFile)
        mock_file.filename = "test.txt"
        mock_file.read = AsyncMock(return_value=b"Test content")

        # Mock DB
        mock_session = AsyncMock()
        mock_db = MagicMock()
        mock_db.get_session.return_value = mock_session

        # Checking for existing: return None
        # Since _find_document_by_hash is internal, we mock the session execution result
        # First call is check existing, return None
        mock_execute_result_existing = MagicMock()
        mock_execute_result_existing.scalar_one_or_none.return_value = None

        # Use return_value for AsyncMock to ensure it's awaitable
        mock_session.execute.return_value = mock_execute_result_existing

        # Define Fake Document class to ensure it's not a coroutine
        class FakeDocument:
            def __init__(self, **kwargs):
                self.id = kwargs.get("id")
                self.file_hash = kwargs.get("file_hash")
                self.original_filename = kwargs.get("original_filename")
                self.file_type = kwargs.get("file_type")
                self.extracted_text = kwargs.get("extracted_text")
                self.summary = kwargs.get("summary")
                self.doc_metadata = kwargs.get("doc_metadata", {})

        @patch(
            "job_analyzer.document_storage.document_manager.Database.get_instance",
            return_value=mock_db,
        )
        @patch(
            "job_analyzer.document_storage.document_manager.extract_document_text",
            new_callable=AsyncMock,
        )
        @patch("utils.document_summarizer.summarize_document", new_callable=AsyncMock)
        @patch(
            "job_analyzer.document_storage.document_manager.DBDocument",
            side_effect=FakeDocument,
        )
        async def run_test(
            mock_db_doc_cls, mock_summarize, mock_extract, mock_db_instance
        ):
            mock_extract.return_value = "Extracted Text"
            mock_summarize.return_value = "Summary"

            doc = await save_uploaded_document(
                mock_file, doc_type="resume", summarize=True
            )

            self.assertIsInstance(doc, UploadedDocument)
            # Extracted Text logic: document_manager now uses summary if available in _map?
            # actually it uses db_doc.summary if present.
            self.assertEqual(doc.extracted_text, "Summary")
            self.assertEqual(doc.original_filename, "test.txt")

            # Verify DB add
            mock_session.add.assert_called_once()
            args, _ = mock_session.add.call_args
            db_doc = args[0]
            # Since we patched DBDocument, checking instance is tricky unless we check against FakeDocument
            self.assertIsInstance(db_doc, FakeDocument)
            self.assertEqual(db_doc.file_hash, "258a12e3e155d04c")

        await run_test()

        await run_test()

    async def test_get_document_cache_hit(self):
        """Test retrieving document from cache."""
        doc_id = "123"
        cached_doc = UploadedDocument(
            id=doc_id,
            file_hash="abc",
            original_filename="test.txt",
            file_type="resume",
            file_format="txt",
            extracted_text="content",
            metadata={},
        )
        _document_cache[doc_id] = cached_doc

        result = await get_document(doc_id)
        self.assertEqual(result, cached_doc)

    async def test_get_document_db_fetch(self):
        """Test retrieving document from DB on cache miss."""
        doc_id = "456"

        # Mock DB Result
        mock_db_doc = DBDocument(
            id=doc_id,
            file_hash="def",
            original_filename="db.txt",
            file_type="resume",
            extracted_text="db content",
            summary="summary",
            doc_metadata={},
        )

        mock_session = AsyncMock()
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = mock_db_doc
        mock_session.execute.return_value = mock_result

        mock_db = MagicMock()
        mock_db.get_session.return_value = mock_session

        @patch(
            "job_analyzer.document_storage.document_manager.Database.get_instance",
            return_value=mock_db,
        )
        async def run_test(mock_get_instance):
            result = await get_document(doc_id)

            self.assertIsNotNone(result)
            self.assertEqual(result.id, doc_id)
            self.assertEqual(result.original_filename, "db.txt")
            # Verify it was added to cache
            self.assertIn(doc_id, _document_cache)

        await run_test()


if __name__ == "__main__":
    unittest.main()
