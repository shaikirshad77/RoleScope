import asyncio
import aiohttp
import json
import logging
import sys

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("test_client")

BASE_URL = "http://localhost:8100/api/v1"
WS_URL = "ws://localhost:8100/api/v1/chat"


async def test_upload_and_chat():
    async with aiohttp.ClientSession() as session:
        # 1. Upload Resume
        logger.info("Step 1: Uploading resume...")
        data = aiohttp.FormData()
        resume_content = b"This is a test resume for John Doe. Skills: Python, FastAPI, AI, Kubernetes.\nExperience: 5 years at Tech Corp."
        data.add_field(
            "file",
            resume_content,
            filename="test_resume.txt",
            content_type="text/plain",
        )

        try:
            async with session.post(f"{BASE_URL}/upload/resume", data=data) as resp:
                if resp.status != 200:
                    text = await resp.text()
                    logger.error(f"Upload failed: {resp.status} - {text}")
                    sys.exit(1)

                upload_resp = await resp.json()
                logger.info(f"Upload successful. Response: {upload_resp}")
                document_id = upload_resp.get("document_id")
                if not document_id:
                    logger.error("No document_id returned!")
                    sys.exit(1)
        except Exception as e:
            logger.error(f"Upload exception: {e}")
            sys.exit(1)

        # 2. Chat with Resume Context
        logger.info(f"Step 2: Connecting to WebSocket with resume_id={document_id}...")
        try:
            async with session.ws_connect(WS_URL) as ws:
                # Send message referencing the resume
                msg = {
                    "message": "What are the main skills listed in the resume?",
                    "resume_id": document_id,
                }
                await ws.send_json(msg)
                logger.info(f"Sent message: {msg}")

                # Wait for response
                logger.info("Waiting for responses (listening for max 60 seconds)...")
                try:
                    while True:
                        # Use receive_str() for aiohttp client
                        response = await asyncio.wait_for(ws.receive_str(), timeout=300)
                        logger.info(f"Received: {response}")

                        # Check for success criteria
                        if (
                            "Python" in response
                            or "FastAPI" in response
                            or "Kubernetes" in response
                        ):
                            logger.info(
                                "SUCCESS: Received response containing resume context!"
                            )
                            break
                        if "Error" in response:
                            logger.error(f"Received error from server: {response}")
                            break
                except asyncio.TimeoutError:
                    logger.warning("Timeout waiting for more messages.")

                await ws.close()
        except Exception as e:
            logger.error(f"WebSocket exception: {e}")
            sys.exit(1)


if __name__ == "__main__":
    asyncio.run(test_upload_and_chat())
